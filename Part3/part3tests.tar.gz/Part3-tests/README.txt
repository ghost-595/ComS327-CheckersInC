
Required functionality: single jumps, no capture

Test files:
------------------------------------------------------------
test??.d(DEPTH).txt  :  single jumps, no forced capture

stress test: depths 5 and higher
------------------------------------------------------------
test04
test06 (slower than test04)

"capture" rule test files:
------------------------------------------------------------
capture??.d(DEPTH).txt

"multiple jump" test files:
------------------------------------------------------------
multi01.d(DEPTH).txt
multi07.d(DEPTH).txt : stress test

